#include <stdio.h>
#include <math.h>
#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#define sum_threshold 2000
#define channels 2048 ////// channels 2048 -----> Volts 10 /////////// 
#define output_size 512

using namespace std;


float a[3][4],l[3];
unsigned short *x,*y;
unsigned int N;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////    GAUSSIAN ELIMINATION in C /////////////////////////////////////////////////////////////
//////////////////////// http://mathworld.wolfram.com/NonlinearLeastSquaresFitting.html  ///////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void forwardSubstitution() {
	int i, j, k, max;
	float t;
	for (i = 0; i < 4; ++i) {
		max = i;
		for (j = i + 1; j < 3; ++j)
			if (a[j][i] > a[max][i])
				max = j;
		
		for (j = 0; j < 4; ++j) {
			t = a[max][j];
			a[max][j] = a[i][j];
			a[i][j] = t;
		}
		
		for (j = 3; j >= i; --j)
			for (k = i + 1; k < 3; ++k)
				a[k][j] -= a[k][i]/a[i][i] * a[i][j];
	}
}

void reverseElimination() {
	int i, j;
	for (i = 2; i >= 0; --i) {
		a[i][3] = a[i][3] / a[i][i];
		a[i][i] = 1;
		for (j = i - 1; j >= 0; --j) {
			a[j][3] -= a[j][i] * a[i][3];
			a[j][i] = 0;
		}
	}
}

void gauss() 
{
    
    forwardSubstitution();
	reverseElimination();
    
}
//////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////////
/////////////    NONLINEAR LEAST SQUARES GAUSSIAN FITTING    ///////////////////////////////////////
///////   http://mathworld.wolfram.com/NonlinearLeastSquaresFitting.html   ////////////////
//////////////////////////////////////////////////////////////////////////////////////////
void gaussfit()
{
  unsigned int i,k,j;
  short temp;
  float db[N],D[N][3],Dt[3][N],dl[3]={1000,1000,1000};
  
  temp = y[0];
  k = 0;
  for (i=0; i<N-1; i++)
  { 
	  if (y[i] < y[i+1])
	  {
		  temp = y[i+1];
	      k = i+1;
	  }
  }
  l[0] = temp;
  l[1] = x[k];
  l[2] = (x[0] - x[N-1])/3;
  
  while (dl[0]>10 || dl[1]>10 || dl[2]>10)
  {
	  for (i=0; i<3; i++)
      { 
	     for (j=0; j<4; j++)
	     {
		  a[i][j] = 0;
	     }
      }
    
      for (i=0; i<N; i++)
      {
	     db[i] = y[i] - l[0]*exp(-(pow(x[i]-l[1],2))/(2*pow(l[2],2)));
         D[i][0] =  exp(-(pow(x[i]-l[1],2))/(2*pow(l[2],2)));
	     D[i][1] =  l[0]*((x[i]-l[1])/(pow(l[2],2)))*exp(-(pow(x[i]-l[1],2))/(2*pow(l[2],2)));
	     D[i][2] =  l[0]*(pow(x[i]-l[1],2)/pow(l[2],3))*exp(-(pow(x[i]-l[1],2))/(2*pow(l[2],2)));
	 
	     for (j=0; j<3; j++)
         {
		    Dt[j][i] = D[i][j];
	        a[j][0] = a[j][0] + Dt[j][i]*D[i][0];
	        a[j][1] = a[j][1] + Dt[j][i]*D[i][1];
	        a[j][2] = a[j][2] + Dt[j][i]*D[i][2];
	        a[j][3] = a[j][3] + Dt[j][i]*db[i];
	     }
       }
   
       gauss();
       for (i=0; i<3; i++)
       {
		   dl[i] =  a[i][3];
           l[i] = l[i] + dl[i];
	    }
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////


int main()
{
  unsigned int hex, count, lines, file_size, i, j, k, m1, m2, xc, yc;
  unsigned int mask1=0xFFF00000,mask2=0x000FFF00,mask3=0x000000FF,mask4=0xF0000000,mask5=0x0FFF0000,mask6=0x0000FFFF;
  unsigned int *hex_data,*temp,*temp1,*temp2,*temp3,*temp4,*temp5,channels_en[channels],channels_xa[channels],channels_xb[channels],channels_yc[channels],channels_yd[channels];;
  unsigned short *ADC0,*ADC1,*ADC2,*ADC3,*time_data,n;
  unsigned short A0,A1,A2,A3,energy;
  
  //////////  Variables for making Image (512 x 512) using Center of Gravity Equations ///////////////////////
  float *xcog, *ycog;
  
  long int **cog_image;
  int il;
  cog_image = (long int **)malloc(sizeof(long int *) * output_size);
  for (il = 0 ;  il < output_size; il++) 
  {
	   cog_image[il] = (long int *)malloc(sizeof(long int) * output_size);
  }
		
	
   //Initialization of image array
   m1=0;
   m2=0;
   for (m1=0; m1<output_size; m1++) 
   {  
      for (m2=0; m2<output_size; m2++) 
	  {	
		  cog_image[m1][m2]=0;
	  }
   }
  ////////////////////////////////////////////////////////////////////////
  
  //////////////// Input and Output files ////////////////////////////////
  
  FILE *input_file = NULL; //// file produced from server.c ///////////
  ofstream target_file0;
  ofstream target_file1;
  ofstream target_file2;
  ofstream target_file3;
  ofstream target_file4;
  ofstream target_file5;
  ////////////////////////////////////////////////////////////////////////
  
  ////////////////////////Put here the output file produced from server.c  (results.txt) /////////////////////////////
  input_file = fopen("results.txt","r");
  
  /////Find the size and lines of the file/////
  fseek ( input_file, 0, SEEK_END);
  file_size=ftell(input_file);
  lines=file_size/9;
  printf("%d\n",lines);
  fclose(input_file);
  
  /////Allocate memory for values to be stored/////
  hex_data = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp1 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp2 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp3 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp4 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp5 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  ADC0 = (unsigned short*)malloc(lines*sizeof(unsigned short ));
  ADC1 = (unsigned short*)malloc(lines*sizeof(unsigned short ));
  ADC2 = (unsigned short*)malloc(lines*sizeof(unsigned short ));
  ADC3 = (unsigned short*)malloc(lines*sizeof(unsigned short ));
  time_data = (unsigned short*)malloc(lines*sizeof(unsigned short));
  
 /////////  Initialize Arrays for Energy, Xa, Xb, Yc, Yd values /////////////////////////////
 for (i=0; i<channels; i++)
  {
	  channels_en[i]=0;
	  channels_xa[i]=0;
	  channels_xb[i]=0;
	  channels_yc[i]=0;
	  channels_yd[i]=0;
  }
  
  ///////// Get data from file and store them to array as integers  ///////////////////////
  input_file = fopen("results.txt","r");
  count=0;
  while(fscanf(input_file,"%x",&hex)==1)
  {
     hex_data[count++]=hex;
  }
  fclose(input_file);
  
  ////////// Open Output files  ///////////////////////////////////
  target_file0.open("image_gauss.txt");     ///// Image (512 x 512 ) ////////////
  target_file1.open("energy_gauss.txt");    ///// Energy Spectrum (2048 channels) ////////
  target_file2.open("xa_gauss.txt");        ///// Xa position spectrum (2048 channels) //////////
  target_file3.open("xb_gauss.txt");        ///// Xb position spectrum (2048 channels) //////////
  target_file4.open("yc_gauss.txt");        ///// Yc position spectrum (2048 channels) //////////
  target_file5.open("yd_gauss.txt");        ///// Yd position spectrum (2048 channels) //////////
  
  ////////////  Seperate ADC0, ADC1, ADC2, ADC3 and TIME data using masks //////////
  j=0;
  for (i=0; i<=lines-1; i += 2)
  {
	  temp[j] = hex_data[i] & mask1;
	  temp[j] >>= 20;
	  temp1[j] = hex_data[i] & mask2;
	  temp1[j] >>= 8;
	  temp2[j] = hex_data[i] & mask3;
	  temp2[j] <<= 4;
	  temp3[j] = hex_data[i+1] & mask4;
	  temp3[j] >>= 28;
	  temp4[j] = hex_data[i+1] & mask5;
	  temp4[j] >>= 16;
	  temp5[j] = hex_data[i+1] & mask6;
	  time_data[j] = temp5[j];
      //////  filter out undesirable pulses ////////
      if ((temp[j] + temp1[j] + (temp2[j] | temp3[j]) + temp4[j]) > sum_threshold)
      {
		  ADC0[j] = temp[j];
		  ADC1[j] = temp1[j];
		  ADC2[j] = temp2[j] | temp3[j];
		  ADC3[j] = temp4[j];
          j++;
	  }
   }
   
   n=0;
   k=0;
   i=0;
   A0=0;
   A1=0;
   A2=0;
   A3=0;
   
for (i=1; i<=j; i++)
   {
	  ///////////////  Find consecutive samples using the timestamp array ///////////////////////////////////////
	  if ((time_data[i+1]-time_data[i]) == 72 || ((time_data[i+1]-time_data[i]) == 144)) ///// 72 for 1.44usec (time between 2 samples) , 144 for 2.88usec (sometimes there is loss of a sample) //////////////////////
      {
		  n++;
	  }
      ////////////// Pulse has n samples ///////////////////////////////////////////////
      else 
      {
		 x = (unsigned short*)malloc((n+1)*sizeof(unsigned short ));
		 y = (unsigned short*)malloc((n+1)*sizeof(unsigned short ));
		 N = n + 1;
      ///////////  Check if pulse exists  /////////////////////////////// 
		 if ((n == 7) || (n == 6) || (n == 5) || (n == 4) || (n == 3)) /////////// 8-11 usec pulse duration (n*1.44) ////////////
		 {

//////////////   Find Pulse Height using Gaussian Fitting to pulse samples //////////////////////////

//////////////////----CHANNEL 0----/////////////////////////////////////
			 
			 for (k=0; k<=n; k++)
		     {
			    x[k] = time_data[i-k];
		        y[k] = ADC0[i-k];
		     }
				 gaussfit();
		         A0 = (unsigned int)(l[0]);
		     
//////////////////----CHANNEL 1----/////////////////////////////////////
		    
		    for (k=0; k<=n; k++)
		     {
			   x[k] = time_data[i-k];
		       y[k] = ADC1[i-k];
		     }
				 gaussfit();
		         A1 = (unsigned int)(l[0]);

//////////////////----CHANNEL 2----/////////////////////////////////////
		     
		     for (k=0; k<=n; k++)
		     {
			   x[k] = time_data[i-k];
		       y[k] = ADC2[i-k];
		     }   
				 gaussfit();
		         A2 = (unsigned int)(l[0]);

//////////////////----CHANNEL 3----/////////////////////////////////////
		     
		     for (k=0; k<=n; k++)
		     {
			   x[k] = time_data[i-k];
		       y[k] = ADC3[i-k];
		     }
				 gaussfit();
		         A3 = (unsigned int)(l[0]);		  
		  
//////////////////////  Sum Energy /////////////////////////////////////	     
		     energy = A0 + A1 + A2 + A3;
		     
////////////////////  Spectrum Arrays ///////////////////////////////	     
		     for (k=0;k<channels-1;k++)
		     {
				 if ((unsigned int)(energy/24) == k)
				 {
					 channels_en[k] = channels_en[k] + 1;
				 }
			     if ((unsigned int)(A0/6) == k)
			     {
					 channels_xa[k] = channels_xa[k] + 1;
				 }
				 if ((unsigned int)(A1/6) == k)
			     {
					 channels_xb[k] = channels_xb[k] + 1;
				 }
				 if ((unsigned int)(A2/6) == k)
			     {
					 channels_yc[k] = channels_yc[k] + 1;
				 }
				 if ((unsigned int)(A3/6) == k)
			     {
					 channels_yd[k] = channels_yd[k] + 1;
				 }
			 }	    

//////////// Initialize variables for Center of Gravity  ////////////////////////////////		  
		 xcog=(float*)malloc(j*sizeof(float)); 
	     
	     ycog=(float*)malloc(j*sizeof(float));
		  
		  
//////////////   Due to small number of samples Gaussian fitting produce wrong results sometimes////////////////////
		 if (((int(A0) > 0) & (int(A1) > 0) & (int(A2) > 0) & (int(A3) > 0)) & ((int(A0) < channels + 1000) & (int(A1) < channels + 1000) & (int(A2) < channels + 1000) & (int(A3) < channels + 1000)))
		     {
			     
////////////  Calculate Center of Gravity  ////////////////////////////////	
			     xcog[i]=(float) A0 / (A0 + A1); 
			     
			     ycog[i]=(float) A2 / (A2 + A3); 
			
			     xc=int(output_size*xcog[i]);
		         
			     yc=int(output_size*ycog[i]);
			     
			     cog_image[xc][yc]=cog_image[xc][yc]+1;
		 }
	 }
		 n=0;
	     A0=0;
	     A1=0;
	     A2=0;
	     A3=0;
	     free(x);
	     free(y);  
	  }  
   }
 
 //////////// Write to image output file //////////////////////////// 	
  	m1=0;
	m2=0;
	for (m1=0; m1<output_size; m1++) 
	{
		for (m2=0; m2<output_size; m2++) 
		{	
			target_file0<<cog_image[m1][m2]<<" ";
		}
			target_file0<<"\n";
	}
	
 /////////// Write to the rest output files //////////////////////////// 
  for (i=0; i<channels - 1; i++)
		 {
			 target_file1<<i<<" "<<channels_en[i]<<"\n";
		     target_file2<<i<<" "<<channels_xa[i]<<"\n";
		     target_file3<<i<<" "<<channels_xb[i]<<"\n";
		     target_file4<<i<<" "<<channels_yc[i]<<"\n";
		     target_file5<<i<<" "<<channels_yd[i]<<"\n";
		 }  
 
  free(hex_data);
  free(time_data);
  free(temp);
  free(temp1);
  free(temp2);
  free(temp3);
  free(temp4);
  free(temp5);
  free(ADC0);
  free(ADC1);
  free(ADC2);
  free(ADC3);
  free(xcog);
  free(ycog);
  target_file0.close();
  target_file1.close();
  target_file2.close();
  target_file3.close();
  target_file4.close();
  target_file5.close();
  return 0;
}

