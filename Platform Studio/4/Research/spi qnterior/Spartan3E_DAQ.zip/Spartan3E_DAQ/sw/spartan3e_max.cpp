#include <stdio.h>
#include <math.h>
#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#define sum_threshold 2000
#define channels 2048 ////// channels 2048 -----> Volts 10 /////////// 
#define output_size 512

using namespace std;



unsigned short *y_0,*y_1,*y_2,*y_3;
unsigned int N,*x;


int main()
{
  unsigned int hex, count, lines, file_size, i, j, k, l1, l2, xc, yc;
  unsigned int mask1=0xFFF00000,mask2=0x000FFF00,mask3=0x000000FF,mask4=0xF0000000,mask5=0x0FFF0000,mask6=0x0000FFFF;
  unsigned int *hex_data,*time_data,*temp,*temp1,*temp2,*temp3,*temp4,*temp5,channels_en[channels],channels_xa[channels],channels_xb[channels],channels_yc[channels],channels_yd[channels];
  unsigned short *ADC0,*ADC1,*ADC2,*ADC3,m0,m1,m2,m3,n,energy;
  
  
  //////////  Variables for making Image (512 x 512) using Center of Gravity Equations ///////////////////////
  float *xcog, *ycog;
  
  long int **cog_image;
  int il;
  cog_image = (long int **)malloc(sizeof(long int *) * output_size);
  for (il = 0 ;  il < output_size; il++) 
  {
	   cog_image[il] = (long int *)malloc(sizeof(long int) * output_size);
  }
		
	
   //Initialization of image array
   m1=0;
   m2=0;
   for (m1=0; m1<output_size; m1++) 
   {  
      for (m2=0; m2<output_size; m2++) 
	  {	
		  cog_image[m1][m2]=0;
	  }
   }
  ////////////////////////////////////////////////////////////////////////
  
//////////////// Input and Output files ////////////////////////////////
  
  FILE *input_file = NULL; //// file produced from server.c ///////////
  ofstream target_file0;
  ofstream target_file1;
  ofstream target_file2;
  ofstream target_file3;
  ofstream target_file4;
  ofstream target_file5;
  ////////////////////////////////////////////////////////////////////////
  
  ////////////////////////Put here the output file produced from server.c  (results.txt) /////////////////////////////  
  input_file = fopen("results.txt","r");
  
  //find the size and lines of the file
  fseek ( input_file, 0, SEEK_END);
  file_size=ftell(input_file);
  lines=file_size/9;
  printf("%d\n",lines);
  fclose(input_file);
  
  //allocate memory for values to be stored
  hex_data = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp1 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp2 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp3 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp4 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  temp5 = (unsigned int*)malloc(lines*sizeof(unsigned int));
  ADC0 = (unsigned short*)malloc(lines*sizeof(unsigned short ));
  ADC1 = (unsigned short*)malloc(lines*sizeof(unsigned short ));
  ADC2 = (unsigned short*)malloc(lines*sizeof(unsigned short ));
  ADC3 = (unsigned short*)malloc(lines*sizeof(unsigned short ));
  time_data = (unsigned int*)malloc(lines*sizeof(unsigned int));
  
 /////////  Initialize Arrays for Energy, Xa, Xb, Yc, Yd values /////////////////////////////
  for (i=0; i<channels; i++)
  {
	  channels_en[i]=0;
	  channels_xa[i]=0;
	  channels_xb[i]=0;
	  channels_yc[i]=0;
	  channels_yd[i]=0;
  }

  ///////// Get data from file and store them to array as integers  ///////////////////////
  input_file = fopen("results.txt","r");
  count=0;
  while(fscanf(input_file,"%x",&hex)==1)
  {
     hex_data[count++]=hex;
  };
  fclose(input_file);
  
  ////////// Open Output files  ///////////////////////////////////
  target_file0.open("image_gauss.txt");     ///// Image (512 x 512 ) ////////////
  target_file1.open("energy_gauss.txt");    ///// Energy Spectrum (2048 channels) ////////
  target_file2.open("xa_gauss.txt");        ///// Xa position spectrum (2048 channels) //////////
  target_file3.open("xb_gauss.txt");        ///// Xb position spectrum (2048 channels) //////////
  target_file4.open("yc_gauss.txt");        ///// Yc position spectrum (2048 channels) //////////
  target_file5.open("yd_gauss.txt");        ///// Yd position spectrum (2048 channels) //////////
  
 ////////////  Seperate ADC0, ADC1, ADC2, ADC3 and TIME data using masks //////////
 j=0;
  for (i=0; i<=lines-1; i += 2)
  {
	  temp[j] = hex_data[i] & mask1;
	  temp[j] >>= 20;
	  temp1[j] = hex_data[i] & mask2;
	  temp1[j] >>= 8;
	  temp2[j] = hex_data[i] & mask3;
	  temp2[j] <<= 4;
	  temp3[j] = hex_data[i+1] & mask4;
	  temp3[j] >>= 28;
	  temp4[j] = hex_data[i+1] & mask5;
	  temp4[j] >>= 16;
	  temp5[j] = hex_data[i+1] & mask6;
	  time_data[j] = temp5[j];
      //////  filter out undesirable pulses ////////
      if ((temp[j] + temp1[j] + (temp2[j] | temp3[j]) + temp4[j]) > sum_threshold)
      {
		  ADC0[j] = temp[j];
		  ADC1[j] = temp1[j];
		  ADC2[j] = temp2[j] | temp3[j];
		  ADC3[j] = temp4[j];
          j++;
	  }
   }
  
   n=0;
   m0=0;
   m1=0;
   m2=0;
   m3=0;
   for (i=0; i<=j-1; i++)
   {
	  ///////////////  Find consecutive samples using the timestamp array ///////////////////////////////////////
	  if (((time_data[i+1]-time_data[i]) == 72) || ((time_data[i+1]-time_data[i]) == 144))///// 72 for 1.44usec (time between 2 samples) , 144 for 2.88usec (sometimes there is loss of a sample) //////////////////////
      {
		  n++;
	  }
      ////////////// Pulse has n samples ///////////////////////////////////////////////
      else 
      {
		 x = (unsigned int*)malloc((n+1)*sizeof(unsigned int ));
		 y_0 = (unsigned short*)malloc((n+1)*sizeof(unsigned short ));
		 y_1 = (unsigned short*)malloc((n+1)*sizeof(unsigned short ));
		 y_2 = (unsigned short*)malloc((n+1)*sizeof(unsigned short ));
		 y_3 = (unsigned short*)malloc((n+1)*sizeof(unsigned short ));
		 N = n + 1;
		 ///////////  Check if pulse exists  /////////////////////////////// 
		 if ( (n == 3) || (n == 4) || (n == 5) || (n == 6) || (n ==7) ) /////////// 8-11 usec pulse duration (n*1.44) ////////////
		 {
			 //////////////  Find Pulse Height using Max Value of pulse samples  //////////////////////////
			 for (k=0; k<=n; k++)
		     {
			    x[k] = time_data[i-k];
		        y_0[k] = ADC0[i-k];
		        y_1[k] = ADC1[i-k];
		        y_2[k] = ADC2[i-k];
		        y_3[k] = ADC3[i-k];
		     }
		     m0 = y_0[0];
		     m1 = y_1[0];
		     m2 = y_2[0];
		     m3 = y_3[0];
		     for (k=0; k<n; k++)
		     {
				if (y_0[k+1] > y_0[k])
				{
					m0 = y_0[k+1];
				}
			    if (y_1[k+1] > y_1[k])
				{
					m1 = y_1[k+1];
				}
				if (y_2[k+1] > y_2[k])
				{
					m2 = y_2[k+1];
				}
				if (y_3[k+1] > y_3[k])
				{
					m3 = y_3[k+1];
				}
			 } 
		     
		     ////////////  Sum Energy /////////////////////////////////////	    
		     energy = m0 + m1 + m2 + m3;
	
		    ////////////  Spectrum Arrays ///////////////////////////////	
		     for (k=0;k<2048;k++)
		     {
				 if ((unsigned int)(energy/24) == k)
				 {
					 channels_en[k] = channels_en[k] + 1;
				     //printf("%d %d\n",k,channels_en[k]);
				 }
			     if ((unsigned int)(m0/6) == k)
			     {
					 channels_xa[k] = channels_xa[k] + 1;
				 }
				 if ((unsigned int)(m1/6) == k)
			     {
					 channels_xb[k] = channels_xb[k] + 1;
				 }
				 if ((unsigned int)(m2/6) == k)
			     {
					 channels_yc[k] = channels_yc[k] + 1;
				 }
				 if ((unsigned int)(m3/6) == k)
			     {
					 channels_yd[k] = channels_yd[k] + 1;
				 }
			 }
		     
		     //////////// Initialize variables for Center of Gravity  ////////////////////////////////		  
		     xcog=(float*)malloc(j*sizeof(float)); 
	     
	         ycog=(float*)malloc(j*sizeof(float));
		  

             ////////////  Calculate Center of Gravity  ////////////////////////////////	
			     xcog[i]=(float) m0 / (m0 + m1); 
			     
			     ycog[i]=(float) m2 / (m2 + m3); 
			
			     xc=int(output_size*xcog[i]);
		         
			     yc=int(output_size*ycog[i]);
			     
			     cog_image[xc][yc]=cog_image[xc][yc]+1;
		 }
		 n=0;
	     m0=0;
	     m1=0;
	     m2=0;
	     m3=0;
	     free(x);
	     free(y_0);
	     free(y_1);
	     free(y_2);
	     free(y_3); 
	  }  
   }
 //////////// Write to image output file //////////////////////////// 	
  	l1=0;
	l2=0;
	for (l1=0; l1<output_size; l1++) 
	{
		for (l2=0; l2<output_size; l2++) 
		{	
			target_file0<<cog_image[l1][l2]<<" ";
		}
			target_file0<<"\n";
	}
	
 /////////// Write to the rest output files //////////////////////////// 
  for (i=0; i<channels - 1; i++)
		 {
			 target_file1<<i<<" "<<channels_en[i]<<"\n";
		     target_file2<<i<<" "<<channels_xa[i]<<"\n";
		     target_file3<<i<<" "<<channels_xb[i]<<"\n";
		     target_file4<<i<<" "<<channels_yc[i]<<"\n";
		     target_file5<<i<<" "<<channels_yd[i]<<"\n";
		 }  
  free(hex_data);
  free(time_data);
  free(temp);
  free(temp1);
  free(temp2);
  free(temp3);
  free(temp4);
  free(temp5);
  free(ADC0);
  free(ADC1);
  free(ADC2);
  free(ADC3);
  free(xcog);
  free(ycog);
  target_file0.close();
  target_file1.close();
  target_file2.close();
  target_file3.close();
  target_file4.close();
  target_file5.close();

  return 0;
}

