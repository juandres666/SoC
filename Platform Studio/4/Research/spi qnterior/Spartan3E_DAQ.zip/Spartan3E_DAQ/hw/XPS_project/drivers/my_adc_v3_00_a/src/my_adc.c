/*****************************************************************************
* Filename:          /home/lefteris/Documents/xilinx/EDK/edk_projects_11_5/spartan3e/DigilentADC_udp_intrp/drivers/my_adc_v3_00_a/src/my_adc.c
* Version:           3.00.a
* Description:       my_adc Driver Source File
* Date:              Wed Sep  7 16:15:42 2011 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "my_adc.h"

/************************** Function Definitions ***************************/

