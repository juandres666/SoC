#include <stdio.h>

#include "xenv_standalone.h"
#include "/home/lefteris/Documents/xilinx/EDK/edk_projects_11_5/spartan3e/DigilentADC_udp_intrp/microblaze_0/include/xparameters.h"
#include "xbasic_types.h"
#include "/home/lefteris/Documents/xilinx/EDK/edk_projects_11_5/spartan3e/DigilentADC_udp_intrp/SDK/SDK_Workspace/Lwip/microblaze_0/include/netif/xadapter.h"


#ifdef XPAR_ETHERNET_MAC_BASEADDR
#define EMAC_BASEADDR  XPAR_ETHERNET_MAC_BASEADDR
#elif XPAR_LLTEMAC_0_BASEADDR 
#define EMAC_BASEADDR  XPAR_LLTEMAC_0_BASEADDR 
#else
#error
#endif

int start_application();
int transfer_data();

int interrupt_flag1;
int interrupt_flag2;
extern Xuint32 k;

/*void
print_ip(char *msg, struct ip_addr *ip) 
{
	print(msg);
	xil_printf("%d.%d.%d.%d\n\r", ip4_addr1(ip), ip4_addr2(ip), 
			ip4_addr3(ip), ip4_addr4(ip));
}

void
print_ip_settings(struct ip_addr *ip, struct ip_addr *mask, struct ip_addr *gw)
{

	print_ip("Board IP: ", ip);
	print_ip("Netmask : ", mask);
	print_ip("Gateway : ", gw);
}
*/

int main()
{
	struct netif *netif, server_netif;
	struct ip_addr ipaddr, netmask, gw;

	/* the mac address of the board. this should be unique per board */
	unsigned char mac_ethernet_address[] = { 0x00, 0x0a, 0x35, 0x00, 0x01, 0x02 };

	netif = &server_netif;

	microblaze_init_icache_range(0, XPAR_MICROBLAZE_0_CACHE_BYTE_SIZE);
	microblaze_init_dcache_range(0, XPAR_MICROBLAZE_0_DCACHE_BYTE_SIZE);

	/* enable caches */
	XCACHE_ENABLE_ICACHE();
	XCACHE_ENABLE_DCACHE();

	platform_setup_interrupts();

	/* initliaze IP addresses to be used */
	IP4_ADDR(&ipaddr,  192, 168,   1, 10);
	IP4_ADDR(&netmask, 255, 255, 255,  0);
	IP4_ADDR(&gw,      192, 168,   1,  1);

	//print_app_header();
	//print_ip_settings(&ipaddr, &netmask, &gw);

	lwip_init();

  	/* Add network interface to the netif_list, and set it as default */
	if (!xemac_add(netif, &ipaddr, &netmask, &gw, mac_ethernet_address, EMAC_BASEADDR)) {
		//xil_printf("Error adding N/W interface\n\r");
		return -1;
	}
	netif_set_default(netif);
	
	platform_enable_interrupts();

	/* specify that the network if is up */
	netif_set_up(netif);

	/* start the application (web server, rxtest, txtest, etc..) */
	start_application();

	/* receive and process packets */

	while (1) {
		xemacif_input(netif);
		//xil_printf("irq1/n");
		if (interrupt_flag1 == 1){
		    //xil_printf("irq1/n");
		    k=262144;
            while (k < 282144)
            {   
		        transfer_data();
                k += 320;
            }
		    interrupt_flag1 = 0;
		}
		if (interrupt_flag2 == 1){
			k=282144;
		    while (k < 302144)
            {   
		        transfer_data();
                k += 320;
            }
		    interrupt_flag2 = 0;
		}
	}
  
	XCACHE_DISABLE_DCACHE();
	XCACHE_DISABLE_ICACHE();

	microblaze_init_dcache_range(0, XPAR_MICROBLAZE_0_DCACHE_BYTE_SIZE);
	microblaze_init_icache_range(0, XPAR_MICROBLAZE_0_CACHE_BYTE_SIZE);


	return 0;
}

