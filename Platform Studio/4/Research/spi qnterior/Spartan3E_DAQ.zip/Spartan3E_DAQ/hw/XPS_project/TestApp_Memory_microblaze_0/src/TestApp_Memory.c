#include "xparameters.h"
#include "xbasic_types.h"
#include "xstatus.h"
#include "my_adc.h"
#include "xintc.h"
#include "xintc_l.h"
#include "stdlib.h"

Xuint32 data,data_old ;
Xuint32 *my_adc_p = (Xuint32 *)XPAR_MY_ADC_0_BASEADDR;
Xuint32 my_adc;

Xuint32 data01[100],data23[100],i;

int main()
{
  i=0;
  while(i<100){
    data01[i] = *(my_adc_p);
    data23[i] = *(my_adc_p + 0x1);
    i++;
  }
  for(i=0;i<100;i++)
    xil_printf("%d\n%x\n",data23[i],data01[i]);
}