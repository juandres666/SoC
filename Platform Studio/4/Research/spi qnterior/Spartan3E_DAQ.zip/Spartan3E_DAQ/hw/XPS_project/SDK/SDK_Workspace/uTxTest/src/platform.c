#include "arch/cc.h"
#include "/home/lefteris/Documents/xilinx/EDK/edk_projects_11_5/spartan3e/DigilentADC_udp_intrp/microblaze_0/include/xparameters.h"
#include "xintc.h"
#include "mb_interface.h"
#include "xtmrctr_l.h"
#include "xbasic_types.h"


extern int interrupt_flag1;
extern int interrupt_flag2;

void cpu_invalidate_dcache_range(unsigned addr, unsigned len)
{
	microblaze_init_dcache_range(addr, len);
}

void platform_enable_interrupts()
{
	microblaze_enable_interrupts();
}

void
timer_callback()
{
	static int odd = 1;
	tcp_fasttmr();

	odd = !odd;
	if (odd)
		tcp_slowtmr();
}

void 
xadapter_timer_handler(void *p)
{
	unsigned *timer_base = (unsigned *)XPAR_XPS_TIMER_0_BASEADDR;
	unsigned tcsr = 0;

	timer_callback();

        /* Load timer, clear interrupt bit */
        XTmrCtr_mSetControlStatusReg(XPAR_XPS_TIMER_0_BASEADDR, 0, XTC_CSR_INT_OCCURED_MASK | XTC_CSR_LOAD_MASK);
	XTmrCtr_mSetControlStatusReg(XPAR_XPS_TIMER_0_BASEADDR, 0, 
			XTC_CSR_ENABLE_TMR_MASK | XTC_CSR_ENABLE_INT_MASK 
			| XTC_CSR_AUTO_RELOAD_MASK | XTC_CSR_DOWN_COUNT_MASK);

        /* start the timer */
        //XTmrCtr_mSetControlStatusReg(XPAR_XPS_TIMER_1_BASEADDR, 0, XTC_CSR_ENABLE_TMR_MASK | XTC_CSR_ENABLE_INT_MASK);

	XIntc_mAckIntr(XPAR_XPS_INTC_0_BASEADDR, XPAR_XPS_TIMER_0_INTERRUPT_MASK);
}

#define MHZ 50
#define TIMER_TLR (250000000*((float)MHZ/100))

void
setup_timer()
{
	/* set the number of cycles the timer counts before interrupting */
	/* 100 Mhz clock => .01us for 1 clk tick. For 100ms, 10000000 clk ticks need to elapse  */
	XTmrCtr_mSetLoadReg(XPAR_XPS_TIMER_0_BASEADDR, 0, TIMER_TLR);

	/* reset the timers, and clear interrupts */
	XTmrCtr_mSetControlStatusReg(XPAR_XPS_TIMER_0_BASEADDR, 0, XTC_CSR_INT_OCCURED_MASK | XTC_CSR_LOAD_MASK );

	/* start the timers */
	XTmrCtr_mSetControlStatusReg(XPAR_XPS_TIMER_0_BASEADDR, 0, 
			XTC_CSR_ENABLE_TMR_MASK | XTC_CSR_ENABLE_INT_MASK 
			| XTC_CSR_AUTO_RELOAD_MASK | XTC_CSR_DOWN_COUNT_MASK);

	/* Register Timer handler */
	XIntc_RegisterHandler(XPAR_XPS_INTC_0_BASEADDR,
			XPAR_XPS_INTC_0_XPS_TIMER_0_INTERRUPT_INTR,
			(XInterruptHandler)xadapter_timer_handler,
			0);

	XIntc_mEnableIntr(XPAR_XPS_INTC_0_BASEADDR, XPAR_XPS_TIMER_0_INTERRUPT_MASK);
}

void adc_intr1_handler(void *baseAddr_p)
{
	 xil_printf("irq1/n");
	 interrupt_flag1 = 1;
     
}

void adc_intr2_handler(void *baseAddr_p)
{
     interrupt_flag2 = 1;
}

XIntc intc;

void platform_setup_interrupts()
{
	XIntc *intcp;
	intcp = &intc;

    XIntc_Initialize(intcp, XPAR_XPS_INTC_0_DEVICE_ID);
	XIntc_Start(intcp, XIN_REAL_MODE);
    
   	XIntc_RegisterHandler(XPAR_INTC_0_BASEADDR, XPAR_XPS_INTC_0_MY_NPI_0_INTERRUPT1_INTR,
   (XInterruptHandler)adc_intr1_handler, (void *)0);
	
	XIntc_RegisterHandler(XPAR_INTC_0_BASEADDR, XPAR_XPS_INTC_0_MY_NPI_0_INTERRUPT2_INTR,
   (XInterruptHandler)adc_intr2_handler, (void *)0);
   
	/* Start the interrupt controller */
	XIntc_mMasterEnable(XPAR_XPS_INTC_0_BASEADDR);

	setup_timer();

#ifdef XPAR_ETHERNET_MAC_IP2INTC_IRPT_MASK
	/* Enable timer and EMAC interrupts in the interrupt controller */
	XIntc_mEnableIntr(XPAR_XPS_INTC_0_BASEADDR, 
		  XPAR_XPS_TIMER_0_INTERRUPT_MASK | 
		  XPAR_ETHERNET_MAC_IP2INTC_IRPT_MASK | XPAR_MY_NPI_0_INTERRUPT1_MASK 
 | XPAR_MY_NPI_0_INTERRUPT2_MASK );
#endif

	microblaze_register_handler((XInterruptHandler)XIntc_InterruptHandler, intcp);

}
