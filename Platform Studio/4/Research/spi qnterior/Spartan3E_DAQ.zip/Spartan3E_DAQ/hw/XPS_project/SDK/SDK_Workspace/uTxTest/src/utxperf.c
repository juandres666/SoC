#include <stdio.h>
#include <string.h>

#include "xbasic_types.h"
#include "/home/lefteris/Documents/xilinx/EDK/edk_projects_11_5/spartan3e/DigilentADC_udp_intrp/microblaze_0/include/xparameters.h"

#include "lwip/err.h"
#include "lwip/udp.h"

static struct udp_pcb *connected_pcb = NULL;
static struct pbuf *pbuf_to_be_sent = NULL;

int interrupt_flag1;
int interrupt_flag2;
Xuint32 k;

Xuint32 *read_ddr_p = (Xuint32 *) XPAR_DDR_SDRAM_MPMC_BASEADDR;

int transfer_data()
{
	int copy = 1;
	err_t err;
	struct udp_pcb *pcb = connected_pcb;
    
    unsigned int temp_str_elements = 320;
    //u32     temp_str[temp_str_elements];

	if (!connected_pcb) {
		return -1;
	}
	
	pbuf_to_be_sent = pbuf_alloc(PBUF_TRANSPORT, 4*temp_str_elements, PBUF_RAM);
    if (!pbuf_to_be_sent){ 
	   //xil_printf("error allocating pbuf to send\n\r");
    return -1;
    }  
    
    
    pbuf_to_be_sent->payload = read_ddr_p + k;
    pbuf_to_be_sent->len = 4*temp_str_elements;

    pbuf_to_be_sent->tot_len = pbuf_to_be_sent->len;
    //pbuf_to_be_sent->next = NULL;
    //pbuf_to_be_sent->type = 0;
    //pbuf_to_be_sent->flags = 0;
    //pbuf_to_be_sent->ref = 0;
    
       
	err = udp_send(pcb, pbuf_to_be_sent);
	if (err != ERR_OK) {
	   //xil_printf("Error on udp_send: %d\n\r", err);
	   return -1;
	}
    pbuf_free(pbuf_to_be_sent);
	
	return 0;
}

int start_application()
{
	struct udp_pcb *pcb;
	struct ip_addr ipaddr;
	err_t err;
	u16_t port;
	int i;

	/* create a udp socket */
	pcb = udp_new();
	if (!pcb) {
		//xil_printf("Error creating PCB. Out of Memory\n\r");
		return -1;
	}

	/* bind local address */
	if ((err = udp_bind(pcb, IP_ADDR_ANY, 0)) != ERR_OK) {
		//xil_printf("error on udp_bind: %x\n\r", err);
	}

	/* connect to iperf server */
	IP4_ADDR(&ipaddr,  192, 168,   1, 11);		/* iperf server address */
	port = 2000;					/* iperf default port */
	err = udp_connect(pcb, &ipaddr, port);
	//xil_printf("udp_connect issued\n\r");

	connected_pcb = pcb;

	return 0;
}

/*void print_app_header()
{
	xil_printf("\n\r\n\r-----lwIP UDP Transmit Test [Board -> Host] ------\n\r");
	xil_printf("To perform UDP TX bandwidth calculation, run iperf from your host machine as: \n\r");
	xil_printf("iperf -u -s -i 5 -t 100\n\r");
	xil_printf("Host should have IP 192.168.1.10 (can be changed in txperf.c)\n\r");
}*/
